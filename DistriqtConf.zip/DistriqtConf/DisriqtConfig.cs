﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace DistriqtConf
{
    class DisriqtConfig
    {
        public string FileName
        {
            get;set;
        }
        public string Adverts
        {
            get;set;
        }

        public string GoogleService
        {
            get;set;
        }

        public void Save()
        {
            Save(FileName);
        }
        public void Save(string fileName)
        {

            XmlDocument doc = new XmlDocument();
            doc.LoadXml("<settings version = \"1.0\"/>");

            doc.FirstChild.Attributes.Append(doc.CreateAttribute("Adverts")).Value = Adverts;
            doc.FirstChild.Attributes.Append(doc.CreateAttribute("GoogleService")).Value = GoogleService;

            doc.Save(fileName);

            FileName = fileName;
        }



        public bool Load(string Filename)
        {
            FileName = Filename;

            XmlDocument doc = new XmlDocument();
            doc.Load(FileName);

            Adverts = doc.FirstChild.Attributes["Adverts"].Value;
            GoogleService = doc.FirstChild.Attributes["GoogleService"].Value;

            return true;
        }
    }
}
