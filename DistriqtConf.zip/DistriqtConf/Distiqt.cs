﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DistriqtConf
{
    public class Distiqt
    {
        public static string[] Anes =
        {
            "com.distriqt.Adverts.ane",
            "com.distriqt.androidsupport.AppCompatV7.ane",
            "com.distriqt.androidsupport.CardViewV7.ane",
            "com.distriqt.androidsupport.CustomTabs.ane",
            "com.distriqt.androidsupport.Design.ane",
            "com.distriqt.androidsupport.InstallReferrer.ane",
            "com.distriqt.androidsupport.RecyclerViewV7.ane",
            "com.distriqt.androidsupport.V4.ane",
            "com.distriqt.Core.ane",
            "com.distriqt.GameServices.AllServices.ane",
            "com.distriqt.InAppBilling.ane",
            "com.distriqt.playservices.Auth.ane",
            "com.distriqt.playservices.Base.ane",
            "com.distriqt.playservices.Drive.ane",
            "com.distriqt.playservices.Games.ane"
        };


    }
}
